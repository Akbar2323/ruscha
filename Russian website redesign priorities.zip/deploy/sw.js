const CACHE = "ruscha-shell-v1";
const APP_SHELL = [
  "./index.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", e=>{
  e.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(APP_SHELL)).then(()=> self.skipWaiting())
  );
});

self.addEventListener("activate", e=>{
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))
      .then(()=> self.clients.claim())
  );
});

// App-shell (the HTML page itself) is cache-first so it opens offline.
// Everything else (audio/video/CDN fonts) is network-first with a cache
// fallback, so online sessions always get the freshest media but a repeat
// visit without a connection still has whatever loaded before.
self.addEventListener("fetch", e=>{
  const req = e.request;
  if(req.method !== "GET") return;
  const isShell = APP_SHELL.some(p => req.url.endsWith(p.replace("./","")) || req.url.endsWith(p));
  if(isShell){
    e.respondWith(
      caches.match(req).then(cached => cached || fetch(req))
    );
    return;
  }
  e.respondWith(
    fetch(req).then(res=>{
      const copy = res.clone();
      caches.open(CACHE).then(cache => cache.put(req, copy)).catch(()=>{});
      return res;
    }).catch(()=> caches.match(req))
  );
});
